from flask import Flask, request,flash, render_template, redirect, url_for, session
import ibm_db
import re
import os
import json
import datetime
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail


app = Flask(__name__)

app.secret_key = 'a'
conn = ibm_db.connect("DATABASE=bludb;HOSTNAME=98538591-7217-4024-b027-8baa776ffad1.c3n41cmd0nqnrk39u98g.databases.appdomain.cloud;PORT=30875;SECURITY=SSL;SSLServerCertificate=DigiCertGlobalRootCA.crt;UID=yfx40903;PWD=2Anl5bloo421K5uf",'','')
print("connected")

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/log')
def log():
    return render_template("login.html")

@app.route('/login', methods= ["POST","GET"])
def login():
    # msg = ''
    
    if request.method == 'POST' :
        USERNAME = request.form['username']
        PASSWORD = request.form['password']
        
        sql="SELECT * FROM USERS WHERE USERNAME = ? AND PASSWORD = ?"
        stmt = ibm_db.prepare(conn, sql)
        ibm_db.bind_param(stmt,1,USERNAME)
        ibm_db.bind_param(stmt,2,PASSWORD)
        ibm_db.execute(stmt)
        account = ibm_db.fetch_assoc(stmt)
        print(account)
        # print('good')
        if account:
            session['Loggedin'] = True
            session['USERID'] = account['USERID']
            session['USERNAME'] = account['USERNAME']
            session['EMAIL'] = account['EMAIL']
            return render_template('dashboard.html')  
        else:
            flash("Incorrect username / Password !")
    return render_template('login.html')       
        
@app.route('/reg')
def reg():
    return render_template("register.html")

@app.route('/register', methods = ['GET','POST'])
def register():
    if request.method == 'POST':
        USERNAME = request.form["username"]
        EMAIL = request.form["email"]
        PASSWORD = request.form["password"]
        sql="SELECT * FROM USERS WHERE USERNAME = ?"
        stmt=ibm_db.prepare(conn,sql)
        ibm_db.bind_param(stmt, 1, USERNAME)
        ibm_db.execute(stmt)
        account= ibm_db.fetch_assoc(stmt) 
                        
        if account:
            msg = 'Account already exists !'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', EMAIL):
            msg = 'Invalid email address !'
        elif not re.match(r'[A-Za-z0-9]+', USERNAME):
            msg = 'username must contain only characters and numbers !'
        else:
            sql = "SELECT COUNT(*) FROM USERS"
            stmt = ibm_db.prepare(conn, sql)
            ibm_db.execute(stmt)
            length = ibm_db.fetch_assoc(stmt)
            print(length)

            insert_sql='INSERT INTO USERS VALUES(?, ?, ?, ?)'
            prep_stmt=ibm_db.prepare(conn,insert_sql)
            ibm_db.bind_param(prep_stmt, 1, length['1']+1)
            ibm_db.bind_param(prep_stmt, 2, USERNAME)
            ibm_db.bind_param(prep_stmt, 3, EMAIL)
            ibm_db.bind_param(prep_stmt, 4, PASSWORD)
            ibm_db.execute(prep_stmt)
            msg = 'You have successfully registered !'
            return render_template("login.html", msg = msg)

    return render_template("register.html")


@app.route('/AddExpense')
def addexpense():
    if 'Loggedin' in session:
        return render_template("addexpense.html", username = session['USERNAME'])
    return redirect(url_for('log'))

@app.route('/UpdateExpense', methods = ["POST","GET"])
def updateexpense():
    msg = ''
    # global USERID 
    if 'Loggedin' in session:
        sql="SELECT * FROM USERS WHERE USERID = " +str(session['USERID'])  
        stmt=ibm_db.prepare(conn, sql)
        ibm_db.execute(stmt)
        data=ibm_db.fetch_tuple(stmt)
        print(data)
        print('hello guys')
           
        if request.method == 'POST' :
            CATEGORY = request.form['category']
            AMOUNT = request.form['amount']
            TIMESTAMP=datetime.datetime.now()

            insert_sql="INSERT INTO EXPENSE VALUES(?, ?, ?, ?, ?, ?)"
            prep_stmt=ibm_db.prepare(conn,insert_sql)
            ibm_db.bind_param(prep_stmt, 1, data[0])
            ibm_db.bind_param(prep_stmt, 2, data[1])
            ibm_db.bind_param(prep_stmt, 3, data[2])
            ibm_db.bind_param(prep_stmt, 4, CATEGORY)
            ibm_db.bind_param(prep_stmt, 5, AMOUNT)
            ibm_db.bind_param(prep_stmt, 6, TIMESTAMP)
            ibm_db.execute(prep_stmt)

            sql1="SELECT * FROM USERINFO WHERE USERID=" +str(session['USERID']) 
            stmt1 = ibm_db.prepare(conn,sql1)
            ibm_db.execute(stmt1)
            accountexpense = ibm_db.fetch_tuple(stmt1)
            print(accountexpense) 
            print('sent')
            limit = accountexpense[2]
            LIMITREM =int(limit) - int(AMOUNT) 
            print(LIMITREM)

            sql="UPDATE USERINFO SET LIMITREM=? WHERE USERID=" +str(session['USERID']) 
            prep_stmt = ibm_db.prepare(conn,sql)
            ibm_db.bind_param(prep_stmt, 1, LIMITREM)
            ibm_db.execute(prep_stmt)

            sql='SELECT LIMITREM FROM USERINFO WHERE userid =' +str(session['USERID']) 
            stmt1 = ibm_db.prepare(conn,sql)
            ibm_db.execute(stmt1)
            remlimitnew = ibm_db.fetch_tuple(stmt1)
            print(remlimitnew)
            print('Mail')
            remlimit = remlimitnew[0]

            if remlimit == 0:
                USERNAME = session['USERNAME']
                EMAIL = session['EMAIL']
                message = Mail(
                    from_email='seethagayathri24@gmail.com',
                    to_emails=EMAIL ,
                    subject='Personal Expense Tracker - Expense Alert',
                    html_content='Hello '+ USERNAME + ',\n\n'+ """\n\nThank you for using Personal Expense Tracker.\nPlease do have control on your expenditure, as you have reached your limit. """)
                try:   
                    sg = SendGridAPIClient('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')
                    response = sg.send(message)
                    print(response.status_code)
                    print(response.body)
                    print(response.headers)
                except Exception as e:
                    print(e.message)

                sql='SELECT NOTIFICATIONS FROM USERINFO WHERE USERID = ' +str(session['USERID'])
                stmt = ibm_db.prepare(conn,sql)
                ibm_db.execute(stmt)
                notification=ibm_db.fetch_tuple(stmt)
                print(notification)
                print('notification done bro')

                notification_no = notification[0]
                notification_no = notification_no + 1
                update_sql='UPDATE USERINFO SET NOTIFICATIONS = ? WHERE USERID ='+str(session['USERID'])
                prep_stmt = ibm_db.prepare(conn,update_sql)
                ibm_db.bind_param(prep_stmt, 1, LIMITREM)
                ibm_db.execute(prep_stmt)

            elif remlimit < 0:
                USERNAME = session['USERNAME']
                EMAIL = session['EMAIL']
                message = Mail(
                    from_email='seethagayathri24@gmail.com',
                    to_emails=EMAIL ,
                    subject='Personal Expense Tracker - Expense Alert',
                    html_content='Hello '+ USERNAME + ',\n\n'+ """\n\nThank you for using Personal Expense Tracker.\nPlease do have control on your expenditure, as you have exceeded your limit. """)
                try:
                    sg = SendGridAPIClient('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')
                    response = sg.send(message)
                    print(response.status_code)
                    print(response.body)
                    print(response.headers)
                except Exception as e:
                    print(e.message)

                sql='SELECT NOTIFICATIONS FROM USERINFO WHERE USERID = ' +str(session['USERID'])
                stmt = ibm_db.prepare(conn,sql)
                ibm_db.execute(stmt)
                notification=ibm_db.fetch_tuple(stmt)
                print(notification)
                print('notification done bro2')
                notification_no = notification[0]
                notification_no += 1 
                update_sql='UPDATE USERINFO SET NOTIFICATION = ? WHERE USERID = ' +str(session['USERID'])
                stmt = ibm_db.prepare(conn,sql)
                ibm_db.bind_param(prep_stmt, 1, notification_no)
                ibm_db.execute(stmt)
                notification=ibm_db.fetch_tuple(stmt)
                msg = "Expense added Successfully !!"   
        else:
            msg = "Something went wrong. Please try again later"
        return render_template("addexpense.html", msg = msg, username= session['USERNAME'])
    return redirect(url_for('log'))

@app.route('/Profile')
def profileinfo():
    if 'Loggedin' in session: 

        sql="SELECT * FROM USERINFO WHERE USERID = " +str(session['USERID']) 
        stmt=ibm_db.prepare(conn,sql)
        # ibm_db.bind_param(stmt, 1, account[0])
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)
        msg3 = account[3]
        LIMIT = account[1]
        LIMITREM = account[2]
        msg4 = int(LIMIT) - int(LIMITREM)   

        sql="SELECT * FROM USERINFO WHERE USERID = " +str(session['USERID']) 
        stmt=ibm_db.prepare(conn,sql)
        # ibm_db.bind_param(stmt, 1, USERID)
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        msg5 =account[1]
        
        sql="SELECT * FROM USERINFO WHERE USERID = "+str(session['USERID']) 
        stmt = ibm_db.prepare(conn,sql)
        # ibm_db.bind_param(stmt, 1, USERID)
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        msg7 = account[2]
        msg6 = msg5-msg7

        sql='SELECT SUM(AMOUNT) AS TOT FROM EXPENSE WHERE USERID =' +str(session['USERID']) 
        stmt = ibm_db.prepare(conn,sql)
        # ibm_db.bind_param(stmt, 1, USERID)
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)
        msg8 = int(account[0])
        return render_template('profile.html',msg3 = msg3, msg4 = msg4, username=session['USERNAME'], msg1 = session['USERNAME'], msg2 = session['EMAIL'], msg5= msg5, msg6= msg6, msg7= msg7, msg8=msg8 )
    return redirect(url_for('log'))

@app.route('/SetLimit')
def setlimit():
    if 'Loggedin' in session:
        return render_template("setlimit.html", username = session['USERNAME'])
    return redirect(url_for('log'))

@app.route('/SetLastMonthLimit')
def setlastmonthlimit():
    if 'Loggedin' in session:
        return render_template("setlastmonthlimit.html", username = session['USERNAME'])
    return redirect(url_for('log'))

@app.route('/UpdateLimit', methods = ["GET","POST"])
def updatelimit():
    msg = ''  

    if 'Loggedin' in session:
                
        if request.method == 'POST':
            LIMITSET = request.form['limit']
            LIMITREM = LIMITSET
            # NOTIFICATIONS= NULL
            sql="SELECT * FROM USERS WHERE USERID = " +str(session['USERID']) 
            stmt=ibm_db.prepare(conn, sql)
            ibm_db.execute(stmt)
            Account=ibm_db.fetch_tuple(stmt)
            print(Account)

            if Account:
                insert_sql1="INSERT INTO USERINFO VALUES(?,?,?, NULL)"
                prep_stmt1=ibm_db.prepare(conn, insert_sql1)
                ibm_db.bind_param(prep_stmt1 , 1 , Account[0])
                ibm_db.bind_param(prep_stmt1 , 2 , LIMITSET)
                ibm_db.bind_param(prep_stmt1 , 3 , LIMITREM)
                # ibm_db.bind_param(prep_stmt , 4 , NOTIFICATIONS)
                ibm_db.execute(prep_stmt1)
                msg = "Limit for expenses updated Successfully !!"   
                return render_template("setlimit.html", msg = msg, username= session['USERNAME'])
            else:
                 msg = "Something went wrong. Please try again later"
                 return render_template("setlimit.html", msg = msg, username= session['USERNAME'])
        return redirect(url_for('log'))    


@app.route('/UpdatewithExistingLimit', methods = ['POST'])
def updatewithexistinglimit():
    if 'Loggedin' in session:
        msg = ''
        if request.method == 'POST':
            sql='SELECT LIMITSET FROM USERINFO WHERE USERID=' +str(session['USERID']) 
            stmt = ibm_db.prepare(conn,sql)
            ibm_db.execute(stmt)
            account=ibm_db.fetch_tuple(stmt)
            print(account)
            account1=account[0]

            msg = "Limit for expenses updated Successfully !!"
        else:
            msg = "Something went wrong. Please try again later"
        return render_template("setlastmonthlimit.html", msg = msg, lastmonth=account1, username= session['USERNAME'])
    return redirect(url_for('log'))


@app.route('/Dashboard')
def dashboard():

    if 'Loggedin' in session:
        
        sql='SELECT COUNT(*) AS TOT FROM USERINFO WHERE USERID=' +str(session['USERID']) 
        stmt = ibm_db.prepare(conn,sql)            
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)
        msg7 = int(account[0])

        sql='SELECT COUNT(NOTIFICATIONS) AS TOT FROM USERINFO WHERE USERID=' +str(session['USERID']) 
        stmt = ibm_db.prepare(conn,sql)           
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)
        msg6 =int(account[0])
        
        sql='SELECT COUNT(*) AS TOT FROM EXPENSE WHERE USERID=' +str(session['USERID']) 
        stmt = ibm_db.prepare(conn,sql)            
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)
        msg5 =int(account[0])
        
        sql='SELECT SUM(AMOUNT) AS TOT FROM EXPENSE WHERE USERID=' +str(session['USERID']) 
        stmt = ibm_db.prepare(conn,sql)
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)
        msg8 =int(account[0])
        
        sql='SELECT LIMITSET FROM USERINFO WHERE USERID=' +str(session['USERID']) 
        stmt = ibm_db.prepare(conn,sql)
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)
        msg11 =account[0]
        
        sql='SELECT LIMITREM FROM USERINFO WHERE USERID=' +str(session['USERID']) 
        stmt = ibm_db.prepare(conn,sql)
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)
        msg33 = account[0]
        msg22 = msg11-msg33
        
        sql='SELECT NOTIFICATIONS FROM USERINFO WHERE USERID=' +str(session['USERID']) 
        stmt = ibm_db.prepare(conn,sql)
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)
        msg44 = account[0]
        USERID = session['USERNAME']

        return render_template('dashboard.html', username=session['USERNAME'], msg5 = msg5, msg6 = msg6, msg7 = msg7, msg8 = msg8, msg11 = msg11, msg22 = msg22, msg33 = msg33, msg44 = msg44)
        
    return redirect(url_for('log'))
  

@app.route('/AllExpenses')
def allexpenses():
    if 'Loggedin' in session:
        data = []
        sql = "SELECT * FROM EXPENSE WHERE USERID=" +str(session['USERID'])
        stmt = ibm_db.prepare(conn,sql)            
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)

        while account != False:
            print('list is here')
            data1 = []
            data1.append(account[3])
            data1.append(account[4])
            data1.append(account[5])
            data.append(data1)
            print(data1)
            account = ibm_db.fetch_tuple(stmt)
        print(data)
     
        return render_template('allexpenses.html', expenses = data, username = session['USERNAME'])
    return redirect(url_for('log'))
    
@app.route('/ReviewExpenses')
def reviewexpenses():
    if 'Loggedin' in session:
        
        data = []
        sql = "SELECT * FROM EXPENSE WHERE USERID=" +str(session['USERID'])
        stmt = ibm_db.prepare(conn,sql)            
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)

        while account != False:
            print('list is here')
            data1 = []
            data1.append(account[3])
            data1.append(account[4])
            data1.append(account[5])
            data.append(data1)
            print(data1)
            account = ibm_db.fetch_tuple(stmt)
        print(data)

        return render_template('reviewexpenses.html', expenses = data, username = session['USERNAME'])
    return redirect(url_for('log'))

@app.route('/ExpensesThisWeek')
def expensesthisweek():
    if 'Loggedin' in session:
        data = []
        sql = "SELECT * FROM EXPENSE WHERE USERID=" +str(session['USERID'])
        stmt = ibm_db.prepare(conn,sql)            
        ibm_db.execute(stmt)
        account=ibm_db.fetch_tuple(stmt)
        print(account)

        while account != False:
            print('list is here')
            data1 = []
            data1.append(account[3])
            data1.append(account[4])
            data1.append(account[5])
            data.append(data1)
            print(data1)
            account = ibm_db.fetch_tuple(stmt)
        print(data)
    
        return render_template('expensesthisweek.html', expenses = data, username = session['USERNAME'])
    return redirect(url_for('log'))

@app.route('/Logout')
def logout():
   session.pop('Loggedin', None)
   session.pop('userid', None)
   session.pop('USERNAME', None)
   session.pop('EMAIL', None)
   flash("Successfully Logged Out!!")
   return redirect(url_for('log'))


@app.route('/analysis')
def analysis():
    global USERID
    if 'Loggedin' in session:
        # datas = []
        sql='SELECT LIMITREM FROM USERINFO WHERE USERID=' +str(session['USERID'])
        stmt = ibm_db.prepare(conn,sql)
        # ibm_db.bind_param(stmt, 1, USERID)
        ibm_db.execute(stmt)
        account = ibm_db.fetch_tuple(stmt)
        print(account)
        print('Gajanannew')
        # while account != False:
        #     dataA = []
        #     dataA.append(account[0])
        #     datas.append(dataA)
        #     account = ibm_db.fetch_tuple(stmt)
        # print(datas)
        msg33 = account[0]  

        sql='SELECT LIMITSET FROM USERINFO WHERE USERID=' +str(session['USERID'])
        stmt = ibm_db.prepare(conn,sql)
        # ibm_db.bind_param(stmt, 1, USERID)
        ibm_db.execute(stmt)
        account = ibm_db.fetch_tuple(stmt)
        print(account)
        msg11 =account[0]

        msg22 = msg11-msg33
        if msg33 <0 :
            msg33=0 

        income_expense = []
        income_expense.append(msg33)
        income_expense.append(msg22)

        data = []
        sql='SELECT TIMESTAMP FROM EXPENSE WHERE USERID=' +str(session['USERID'])
        stmt = ibm_db.prepare(conn,sql)
        # ibm_db.bind_param(stmt, 1, USERID)
        ibm_db.execute(stmt)
        dates = ibm_db.fetch_tuple(stmt)
        print(dates)
        print("gajanan")
        while dates != False:
            data1 = []
            data1.append(dates[0])
            data.append(data1)
            dates = ibm_db.fetch_tuple(stmt)
        print(data)
        
        expenses_done =[]
        sql='SELECT AMOUNT FROM EXPENSE WHERE USERID=' +str(session['USERID'])
        stmt = ibm_db.prepare(conn,sql)
        # ibm_db.bind_param(stmt, 1, USERID)
        ibm_db.execute(stmt)
        expenses = ibm_db.fetch_tuple(stmt)
        print(expenses)
        while expenses != False:
            dataA = []
            dataA.append(expenses[0])
            expenses_done.append(dataA)
            expenses = ibm_db.fetch_tuple(stmt)
        print(expenses_done)
        
        # for expense_amount in expenses_done:
        #     expenses_done.append(expense_amount[0])
        
        dates_label = []
        for dateval in data:
            dates_label.append(str(dateval[0]))

        return render_template('chart.html',income_vs_expense=json.dumps(income_expense), expenses_done=json.dumps(expenses_done),
                                dates_label =json.dumps(dates_label), username = session['USERNAME'])
    return redirect(url_for('log'))


if __name__ == '__main__':
    app.run(debug=True)